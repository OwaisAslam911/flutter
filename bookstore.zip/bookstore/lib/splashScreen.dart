// import 'dart:math';
// import 'package:flutter/material.dart';
// import 'package:flip_card/flip_card.dart';

// void main() => runApp(const MyApp());

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Book Store Splash',
//       theme: ThemeData.dark(),
//       home: const BookSplashScreen(),
//     );
//   }
// }

// class BookSplashScreen extends StatefulWidget {
//   const BookSplashScreen({super.key});

//   @override
//   _BookSplashScreenState createState() => _BookSplashScreenState();
// }

// class _BookSplashScreenState extends State<BookSplashScreen>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _diamondController;
//   final List<DiamondData> _diamonds = [];
//   final GlobalKey<FlipCardState> _bookKey = GlobalKey<FlipCardState>();
//   final Random _random = Random();

//   @override
//   void initState() {
//     super.initState();
//     _diamondController = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 15),
//     )..repeat();

//     // Initialize diamonds
//     for (int i = 0; i < 30; i++) {
//       _diamonds.add(DiamondData(
//         id: i,
//         x: _random.nextDouble(),
//         size: 0.2 + _random.nextDouble() * 0.3,
//         speed: 0.5 + _random.nextDouble(),
//         delay: _random.nextDouble() * 2,
//       ));
//     }

//     // Trigger book flip after 2 seconds
//     Future.delayed(const Duration(seconds: 2), () {
//       _bookKey.currentState?.toggleCard();
//     });
//   }

//   @override
//   void dispose() {
//     _diamondController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final size = MediaQuery.of(context).size;
//     final halfHeight = size.height / 2;

//     return Scaffold(
//       body: Stack(
//         children: [
//           // Background
//           Container(
//             decoration: const BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topCenter,
//                 end: Alignment.bottomCenter,
//                 colors: [Colors.black87, Color(0xFF0d1b2a)],
//               ),
//             ),
//           ),

//           // Rising diamonds
//           for (final diamond in _diamonds)
//             AnimatedBuilder(
//               animation: _diamondController,
//               builder: (context, child) {
//                 final time = (_diamondController.value * diamond.speed) + diamond.delay;
//                 final yPosition = (1 - (time % 1)) * size.height * 1.5;
//                 final normalizedHeight = yPosition / halfHeight;
//                 final currentSize = diamond.size * min(1.0, 1.5 - normalizedHeight);

//                 return Positioned(
//                   left: diamond.x * size.width,
//                   top: yPosition,
//                   child: Transform.scale(
//                     scale: max(0.2, currentSize),
//                     child: Transform.rotate(
//                       angle: pi / 4,
//                       child: Container(
//                         width: 40,
//                         height: 40,
//                         decoration: BoxDecoration(
//                           color: Colors.blue.withOpacity(0.7),
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),

//           // Book with flip animation
//           Center(
//             child: FlipCard(
//               key: _bookKey,
//               flipOnTouch: false,
//               speed: 700,
//               front: _buildBookCover(),
//               back: _buildBookPage(),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildBookCover() {
//     return Container(
//       width: 200,
//       height: 280,
//       decoration: BoxDecoration(
//         color: const Color(0xFF1b263b),
//         borderRadius: BorderRadius.circular(8),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.blue.withOpacity(0.6),
//             blurRadius: 20,
//             spreadRadius: 2,
//           )
//         ],
//       ),
//       child: const Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(Icons.menu_book, size: 60, color: Colors.blueAccent),
//           SizedBox(height: 20),
//           Text('Book Store',
//               style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
//         ],
//       ),
//     );
//   }

//   Widget _buildBookPage() {
//     return Container(
//       width: 200,
//       height: 280,
//       decoration: BoxDecoration(
//         color: const Color(0xFFe0e1dd),
//         borderRadius: BorderRadius.circular(8),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.blue.withOpacity(0.6),
//             blurRadius: 20,
//             spreadRadius: 2,
//           )
//         ],
//       ),
//       child: const Padding(
//         padding: EdgeInsets.all(20.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Chapter 1',
//                 style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//             SizedBox(height: 15),
//             Text('Once upon a time in a digital bookstore, magical things happened...',
//                 style: TextStyle(fontSize: 14)),
//             Spacer(),
//             Align(
//               alignment: Alignment.bottomRight,
//               child: Text('Page 1', style: TextStyle(fontStyle: FontStyle.italic)),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class DiamondData {
//   final int id;
//   final double x;
//   final double size;
//   final double speed;
//   final double delay;

//   DiamondData({
//     required this.id,
//     required this.x,
//     required this.size,
//     required this.speed,
//     required this.delay,
//   });
// }

import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SplashBookAnimation(),
    );
  }
}

class SplashBookAnimation extends StatefulWidget {
  @override
  _SplashBookAnimationState createState() => _SplashBookAnimationState();
}

class _SplashBookAnimationState extends State<SplashBookAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: 0.0, end: pi).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[100],
      body: Center(
        child: AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.001)
                ..rotateY(_animation.value),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Image.asset('assets/book_back.png'), // Back of the book
                  if (_animation.value <= pi / 2)
                    Image.asset('assets/book_front.png') // Front flipping page
                  else
                    Image.asset('assets/book_inner.png'), // Inner page
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
