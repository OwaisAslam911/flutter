
import 'package:crud_app/addproduct.dart';
import 'package:flutter/material.dart';
import 'package:crud_app/products.dart';


class DrawerSide extends StatefulWidget {
  const DrawerSide({ Key? key }) : super(key: key);

  @override
  _DrawerSideState createState() => _DrawerSideState();
}

class _DrawerSideState extends State<DrawerSide> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blueAccent,
            ),
            child: Text(
              'Drawer Header',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Add Products'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => Addproduct()));         },
          ),
          ListTile(
            leading: Icon(Icons.laptop),
            title: Text('Products'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => Products()));
            },
          ),
        
        ],
      ),
    );
  }
}