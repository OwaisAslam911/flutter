
import 'package:crud_app/addproduct.dart';
import 'package:crud_app/products.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:crud_app/firebase_options.dart';
import 'package:flutter/material.dart';

void main()async {

  await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform,
);
   runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Products()
    ),
  );
}

// import 'package:crud_app/firebase_options.dart';
// import 'package:crud_app/products.dart';
// import 'package:device_preview/device_preview.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';

// void  main() async => runApp(
  
//   DevicePreview(
//     enabled: !kReleaseMode,
//     builder: (context) => MyApp(), // Wrap your app
//   ),
  
// );

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       locale: DevicePreview.locale(context),
//       builder: DevicePreview.appBuilder,
//       theme: ThemeData.light(),
//       darkTheme: ThemeData.dark(),
//       home: const Products(),
//     );
//   }
// }