
import 'package:flutter/material.dart';
import 'package:my_app/apiProduct.dart';
import 'package:my_app/darazScreen.dart';
import 'package:my_app/dynamicList.dart';
import 'package:my_app/firstScreen.dart';
import 'package:my_app/musicPlayList.dart';
import 'package:my_app/product.dart';
import 'package:my_app/signup.dart';

class DrawerSide extends StatefulWidget {
  const DrawerSide({ Key? key }) : super(key: key);

  @override
  _DrawerSideState createState() => _DrawerSideState();
}

class _DrawerSideState extends State<DrawerSide> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blueAccent,
            ),
            child: Text(
              'Drawer Header',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Home'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => ApiProduct()));         },
          ),
          ListTile(
            leading: Icon(Icons.laptop),
            title: Text('Daraz Screen'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => DarazScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.laptop),
            title: Text('Laptops'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => DynamicList()));
            },
          ),
          ListTile(
            leading: Icon(Icons.laptop),
            title: Text('API Products'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => FirstScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('product'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => Product()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('product'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => Signup()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Music Playlist'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => MusicPlayList()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('dynamic list'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder:  (context) => DynamicList()));
            },
          ),
        ],
      ),
    );
  }
}