import 'package:flutter/material.dart';
import 'package:my_app/ElectricityBill.dart';
import 'package:my_app/drawerSide.dart';

class BillCalculator extends StatefulWidget {
  const BillCalculator({ Key? key }) : super(key: key);

  @override
  _BillCalculatorState createState() => _BillCalculatorState();
}

class _BillCalculatorState extends State<BillCalculator> {
  final GlobalKey<FormState> myFormKey = GlobalKey<FormState>();
  TextEditingController unitsController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController taxPercentController = TextEditingController();

double units = 0,
pricePerUnit = 0,
taxPercent =0,
billAmount = 0,
taxAmount = 0,
finalBillAmount = 0;

var billDetails = ();
void CalculateBill(){
  if(myFormKey.currentState!.validate()){
    units = double.parse(unitsController.text);
    pricePerUnit = double.parse(priceController.text);
    taxPercent = double.parse(taxPercentController.text);

    billAmount = units* pricePerUnit;
    taxAmount = (billAmount * taxPercent)/100;
    setState(() {
      finalBillAmount =billAmount + taxAmount;
    }
    );
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ElectricityBill(finalBillAmount: finalBillAmount),
        ),
      );
    print("Final Bill Amount: ${finalBillAmount}");
  }else{
    print("Please Enter Valid Details");
  }
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Colors.black,
        title: Text("Bill Calculator"),
        centerTitle: true,
      ),
      drawer: DrawerSide(),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blueAccent, Colors.greenAccent, Colors.lightBlue],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Form(
          key: myFormKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Custom Text Form Field for Units
                _buildCustomTextField(
                  controller: unitsController,
                  label: 'Units Consumed',
                  icon: Icons.energy_savings_leaf_outlined,
                  keyboardType: TextInputType.number,
                ),

                // Custom Text Form Field for Price per Unit
                _buildCustomTextField(
                  controller: priceController,
                  label: 'Price per Unit',
                  icon: Icons.attach_money,
                  keyboardType: TextInputType.number,
                ),

                // Custom Text Form Field for Tax Percentage
                _buildCustomTextField(
                  controller: taxPercentController,
                  label: 'Tax Percentage',
                  icon: Icons.percent,
                  keyboardType: TextInputType.number,
                ),

                SizedBox(height: 20),

                // Calculate Button
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      // primary: Colors.deepPurple,
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      elevation: 5,
                    ),
                    onPressed: CalculateBill,
                    child: Text(
                      'Calculate Bill',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),

                SizedBox(height: 30),

                // Show Final Bill Amount if greater than 0
                if (finalBillAmount > 0)
                  Center(
                    child: Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                          ),
                        ],
                      ),
                      child: Text(
                        'Total Bill Amount: \$${finalBillAmount.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[700],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Custom Text Field Widget
  Widget _buildCustomTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required TextInputType keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.black),
          labelText: label,
          labelStyle: TextStyle(fontSize: 16, color: Colors.black),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.black, width: 1.5),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blueAccent, width: 2),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) return 'Please enter a valid $label';
          return null;
        },
      ),
    );
  }
}