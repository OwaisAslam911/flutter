import 'package:flutter/material.dart';
import 'package:my_app/drawerSide.dart';

class ElectricityBill extends StatefulWidget {
  final double finalBillAmount;

  // Constructor for ElectricityBill that requires finalBillAmount
  const ElectricityBill({Key? key, required this.finalBillAmount}) : super(key: key);

  @override
  _ElectricityBillState createState() => _ElectricityBillState();
}

class _ElectricityBillState extends State<ElectricityBill> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Colors.black,
        title: Text("Bill amount"),
        centerTitle: true,
      ),
      drawer: DrawerSide(),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
              ),
            ],
          ),
          child: Text(
            'Total Bill Amount: ${widget.finalBillAmount.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.green[700],
            ),
          ),
        ),
      ),
    );
  }
}
