import 'package:flutter/material.dart';
import 'package:my_app/drawerSide.dart';

class MusicPlayList extends StatefulWidget {
  const MusicPlayList({Key? key}) : super(key: key);

  @override
  _MusicPlayListState createState() => _MusicPlayListState();
}

class _MusicPlayListState extends State<MusicPlayList> {
  var singerList = [
    {"name": "Arijit Singh", "image": "Arijit.jpg", "songs": "200+ songs"},
    {"name": "Ali Zafar", "image": "aliZafar.jpg", "songs": "100+ songs"},
    {"name": "atif aslam", "image": "atif.jpg", "songs": "120+ songs"},
    {"name": "Sherya Singh", "image": "shreya.jpg", "songs": "55+ songs"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFFCF6FF),
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black87),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16.0),
            child: Icon(Icons.search),
          ),
        ],
      ),
      drawer: DrawerSide(),
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // App bar row

              // Title
              Text(
                'Thrilling Week',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              SizedBox(height: 4),
              Text(
                '2025 top songs to hang on',
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 20),

              // Explore + icon
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    'Explore',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Icon(Icons.local_fire_department, color: Colors.blueAccent),
                ],
              ),
              SizedBox(height: 10),

              // Category Tabs (Recommended, etc.)
              Row(
                children: const [
                  Text(
                    'Recommended',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(width: 16),
                  Text('2025 songs'),
                  SizedBox(width: 16),
                  Text('New songs'),
                ],
              ),
              SizedBox(height: 16),

              // Horizontal list of singers
              SizedBox(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: singerList.length,
                  itemBuilder: (context, index) {
                    var singer = singerList[index];
                    return Container(
                      width: 140,
                      margin: EdgeInsets.only(right: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey,
                            blurRadius: 4,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(12),
                            ),
                            child: Image.asset(
                              singer['image']!,
                              height: 120,
                              width: 140,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 4,
                            ),
                            child: Column(
                              children: [
                                Text(
                                  singer['name']!,
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      singer['songs']!,
                                      style: TextStyle(
                                        color: Colors.grey[600],
                                        fontSize: 12,
                                      ),
                                    ),
                                    SizedBox(width: 4),
                                    Icon(
                                      Icons.favorite,
                                      size: 14,
                                      color: Colors.black,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
